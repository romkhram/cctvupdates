"use strict";(self["webpackChunkdemoApp"]=self["webpackChunkdemoApp"]||[]).push([[811],{811:function(e,t,n){n.r(t),n.d(t,{startStatusTap:function(){return i}});var o=n(332),r=n(842),s=n(627);
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const i=()=>{const e=window;e.addEventListener("statusTap",(()=>{(0,o.wj)((()=>{const t=e.innerWidth,n=e.innerHeight,i=document.elementFromPoint(t/2,n/2);if(!i)return;const a=(0,r.a)(i);a&&new Promise((e=>(0,s.c)(a,e))).then((()=>{(0,o.Iu)((async()=>{a.style.setProperty("--overflow","hidden"),await(0,r.s)(a,300),a.style.removeProperty("--overflow")}))}))}))}))}}}]);
//# sourceMappingURL=811.b12962b6.js.map